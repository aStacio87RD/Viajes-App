import pytest
from app import create_app

@pytest.fixture
def client():
    app = create_app()
    app.config['TESTING'] = True
    return app.test_client()

def test_home(client):
    res = client.get('/')
    assert res.status_code == 200

def test_login(client):
    res = client.get('/login')
    assert res.status_code == 200

def test_explorar(client):
    res = client.get('/explorar')
    assert res.status_code == 200